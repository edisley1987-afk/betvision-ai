# BetVision AI v5
Login e Banco (estrutura inicial).
