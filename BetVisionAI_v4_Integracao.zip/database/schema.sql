-- esquema inicial
CREATE TABLE IF NOT EXISTS historico(id INTEGER PRIMARY KEY, jogo TEXT);